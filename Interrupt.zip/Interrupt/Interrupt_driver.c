#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kdev_t.h>
#include <linux/fs.h>
#include <linux/err.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/interrupt.h>

dev_t my_dev;
static struct class *dev_class;
static struct cdev my_cdev;

#define CHR_DEV_NAME "dynamic_driver"
#define CLASS_NAME "my_class"
#define DEVICE_NAME "my_device"

static irqreturn_t irq_handler(int irq,void *dev_id) 
{
	printk(KERN_INFO "Shared IRQ: Interrupt Occurred");
	return IRQ_HANDLED;
}

static int      file_open(struct inode *inode, struct file *fp);
static int      file_release(struct inode *inode, struct file *fp);
static ssize_t  file_read(struct file *fp, char __user *buf, size_t len,loff_t * off);
static ssize_t  file_write(struct file *fp, const char *buf, size_t len, loff_t * off);

static struct file_operations fops =
{
	.owner      = THIS_MODULE,
	.read       = file_read,
	.write      = file_write,
	.open       = file_open,
	.release    = file_release,
};

static int file_open(struct inode *inode, struct file *fp)
{
	pr_info("Driver Open Function Called...!!!\n");
	return 0;
}

static int file_release(struct inode *inode, struct file *fp)
{
	pr_info("Driver Release Function Called...!!!\n");
	return 0;
}

static ssize_t file_read(struct file *fp, char __user *buf, size_t len, loff_t *off)
{
	pr_info("Driver Read Function Called...!!!\n");
	return 0;
}

static ssize_t file_write(struct file *fp, const char __user *buf, size_t len, loff_t *off)
{
	pr_info("Driver Write Function Called...!!!\n");
	return len;
}

static int __init my_driver_init(void)
{
	alloc_chrdev_region(&my_dev, 0, 1, CHR_DEV_NAME);
	printk(KERN_INFO "MAJOR no.: %d, MINOR no.: %d\n", MAJOR(my_dev), MINOR(my_dev));

	dev_class = class_create(THIS_MODULE, CLASS_NAME);

	device_create(dev_class, NULL, my_dev, NULL, DEVICE_NAME);

	cdev_init(&my_cdev,&fops);
	cdev_add(&my_cdev, my_dev, 1);

	if(request_irq(1, irq_handler, IRQF_SHARED, DEVICE_NAME, (void *)(irq_handler)))
	{
		printk(KERN_INFO "my_device cannot register IRQ\n");
		free_irq(1, (void *)(irq_handler));
	}

	printk(KERN_INFO "Driver inserted successfully\n");

	return 0;
}

static void __exit my_driver_exit(void)
{
	free_irq(1,(void *)(irq_handler));
	device_destroy(dev_class, my_dev);
	class_destroy(dev_class);
	cdev_del(&my_cdev);
	unregister_chrdev_region(my_dev, 1);
	printk(KERN_INFO "Driver removed successfully\n");
}


module_init(my_driver_init);
module_exit(my_driver_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Rakshitha S");
